export default {
  init({ register, mongo, eventBus }) {

    const Attendance = register.model('attendance', {
      user_id: String,
      timestamp: Date
    });

    register.route('/attendance', (router) => {
      router.post('/', async (req, res) => {
        const data = await Attendance.create(req.body);
        eventBus.emit('attendance.created', data);
        res.json(data);
      });
    });

    register.action('attendance.created', (payload) => {
      console.log('Attendance event:', payload);
    });
  }
};
